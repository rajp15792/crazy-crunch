import React, { useState } from 'react';
import { X, ShieldCheck, Banknote, QrCode, AlertCircle, Loader2, MapPin, ShoppingBag } from 'lucide-react';

export default function CheckoutModal({
  isOpen,
  onClose,
  cart,
  settings,
  onSubmitOrder
}) {
  if (!isOpen) return null;

  const [customer, setCustomer] = useState({
    name: '',
    phone: '',
    address: '',
    area: '',
    city: '',
    pincode: '',
    notes: ''
  });
  const [paymentMethod, setPaymentMethod] = useState('COD'); // 'COD' or 'UPI'
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const minForFree = settings?.minOrderForFreeDelivery || 299;
  const standardDelivery = settings?.deliveryCharge || 30;
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryCharge = cart.length === 0 ? 0 : subtotal >= minForFree ? 0 : standardDelivery;
  const grandTotal = subtotal + deliveryCharge;

  // Generate UPI payment intent string
  const upiId = settings?.upiId || 'crazycrunch@upi';
  const upiPayUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(
    'Crazy Crunch'
  )}&am=${grandTotal}&cu=INR&tn=${encodeURIComponent('Snacks Order')}`;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return; // Guard against duplicate submissions
    setError('');

    // Strict Field Validations
    if (!customer.name.trim()) {
      setError('Please enter your full name.');
      return;
    }

    const cleanPhone = customer.phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 10) {
      setError('Please enter a valid 10-digit mobile phone number.');
      return;
    }

    if (!customer.address.trim()) {
      setError('Please enter your complete delivery house/flat number and street address.');
      return;
    }

    if (!customer.area.trim()) {
      setError('Please enter your Area or Locality.');
      return;
    }

    if (!customer.city.trim()) {
      setError('Please enter your City or Town.');
      return;
    }

    const cleanPincode = customer.pincode.replace(/[^0-9]/g, '');
    if (cleanPincode.length !== 6) {
      setError('Please enter a valid 6-digit delivery PIN code.');
      return;
    }

    if (!cart || cart.length === 0) {
      setError('Your shopping cart is empty.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmitOrder({
        customer: {
          name: customer.name.trim(),
          phone: cleanPhone.slice(-10),
          address: customer.address.trim(),
          area: customer.area.trim(),
          city: customer.city.trim(),
          pincode: cleanPincode,
          notes: customer.notes ? customer.notes.trim() : ''
        },
        items: cart.map((i) => ({ id: i.id, quantity: i.quantity, price: i.price, name: i.name })),
        paymentMethod
      });
      // Submission handled by parent which closes modal and opens success confirmation
    } catch (err) {
      setError(err.message || 'Failed to place order. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl relative my-8 border border-orange-100 max-h-[92vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
          <div>
            <h3 className="text-xl font-black text-slate-900 leading-tight">Delivery & Checkout</h3>
            <p className="text-xs text-slate-500 mt-0.5">Verified prices & real-time stock reservation</p>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Content */}
        <div className="flex-1 overflow-y-auto py-3.5 space-y-4 pr-1">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-2.5 text-xs text-red-700 animate-shake">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Product Items Breakdown Before Confirmation */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-800 border-b border-slate-200/60 pb-1.5">
              <span className="flex items-center gap-1.5">
                <ShoppingBag className="w-3.5 h-3.5 text-orange-600" />
                <span>Order Summary ({cart.length} snacks)</span>
              </span>
              <span className="text-[11px] font-semibold text-slate-500">
                {deliveryCharge === 0 ? (
                  <strong className="text-emerald-600 font-bold">FREE Delivery</strong>
                ) : (
                  `₹${deliveryCharge} Delivery`
                )}
              </span>
            </div>

            <div className="max-h-28 overflow-y-auto space-y-1 text-xs pr-1">
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between items-center text-slate-700">
                  <span className="truncate pr-2">
                    {item.name} {item.weight ? `(${item.weight})` : ''} × <strong>{item.quantity}</strong>
                  </span>
                  <span className="font-bold shrink-0 text-slate-900">
                    ₹{item.price * item.quantity}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-xs">
              <span className="font-medium text-slate-500">Subtotal: ₹{subtotal}</span>
              <span className="font-black text-sm text-orange-700">Grand Total: ₹{grandTotal}</span>
            </div>
          </div>

          <form id="checkout-form" onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Full Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                disabled={isSubmitting}
                placeholder="e.g. Ramesh Patil"
                value={customer.name}
                onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Mobile Phone Number <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  disabled={isSubmitting}
                  maxLength={10}
                  placeholder="9876543210"
                  value={customer.phone}
                  onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                  className="w-full pl-12 pr-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white disabled:opacity-60"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Complete Delivery Address <span className="text-red-500">*</span>
              </label>
              <textarea
                required
                disabled={isSubmitting}
                rows={2}
                placeholder="House / Flat No., Building name, Street, Landmark..."
                value={customer.address}
                onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white resize-none disabled:opacity-60"
              ></textarea>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Area / Locality <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  disabled={isSubmitting}
                  placeholder="e.g. Shivaji Nagar"
                  value={customer.area}
                  onChange={(e) => setCustomer({ ...customer, area: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white disabled:opacity-60"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  City <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  disabled={isSubmitting}
                  placeholder="e.g. Kolhapur"
                  value={customer.city}
                  onChange={(e) => setCustomer({ ...customer, city: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white disabled:opacity-60"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  PIN Code <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  disabled={isSubmitting}
                  maxLength={6}
                  placeholder="e.g. 416001"
                  value={customer.pincode}
                  onChange={(e) => setCustomer({ ...customer, pincode: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white disabled:opacity-60 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Delivery Instructions (Optional)
              </label>
              <input
                type="text"
                disabled={isSubmitting}
                placeholder="e.g. Ring bell, deliver after 5 PM, leave at gate..."
                value={customer.notes}
                onChange={(e) => setCustomer({ ...customer, notes: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white disabled:opacity-60"
              />
            </div>

            {/* Payment Method Selector */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Payment Method
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                {/* Cash on Delivery */}
                <label
                  className={`flex flex-col p-3 rounded-2xl border cursor-pointer transition-all ${
                    paymentMethod === 'COD'
                      ? 'border-orange-500 bg-orange-50/50 shadow-sm'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <Banknote className="w-5 h-5 text-emerald-600" />
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="COD"
                      checked={paymentMethod === 'COD'}
                      onChange={() => setPaymentMethod('COD')}
                      className="accent-orange-600"
                    />
                  </div>
                  <span className="text-xs font-bold text-slate-900">Cash on Delivery</span>
                  <span className="text-[10px] text-slate-500 mt-0.5">Pay cash upon arrival</span>
                </label>

                {/* Direct UPI */}
                <label
                  className={`flex flex-col p-3 rounded-2xl border cursor-pointer transition-all ${
                    paymentMethod === 'UPI'
                      ? 'border-orange-500 bg-orange-50/50 shadow-sm'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <QrCode className="w-5 h-5 text-indigo-600" />
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="UPI"
                      checked={paymentMethod === 'UPI'}
                      onChange={() => setPaymentMethod('UPI')}
                      className="accent-orange-600"
                    />
                  </div>
                  <span className="text-xs font-bold text-slate-900">UPI / QR Scan</span>
                  <span className="text-[10px] text-slate-500 mt-0.5">GPay, PhonePe, Paytm</span>
                </label>
              </div>

              {/* UPI Information Box */}
              {paymentMethod === 'UPI' && (
                <div className="mt-2.5 p-3 bg-indigo-50 border border-indigo-200/80 rounded-2xl text-xs text-indigo-950 space-y-2">
                  <div className="font-semibold flex items-center justify-between">
                    <span>Store UPI ID:</span>
                    <code className="bg-white px-2 py-0.5 rounded font-mono font-bold text-indigo-700">
                      {upiId}
                    </code>
                  </div>
                  <p className="text-[11px] text-indigo-800">
                    Pay securely using any UPI app. Zero gateway fees. We never ask for your UPI PIN.
                  </p>
                  <a
                    href={upiPayUrl}
                    className="block w-full text-center py-2 bg-indigo-600 text-white rounded-xl font-bold text-xs hover:bg-indigo-700 transition-colors"
                  >
                    Open UPI App on Phone (₹{grandTotal})
                  </a>
                </div>
              )}
            </div>
          </form>
        </div>

        {/* Modal Footer */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 transition-colors disabled:opacity-50"
          >
            Cancel
          </button>

          <button
            type="submit"
            form="checkout-form"
            disabled={isSubmitting}
            className="flex-1 py-2.5 px-4 bg-orange-600 hover:bg-orange-700 active:scale-[0.98] disabled:bg-slate-300 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-orange-600/25 transition-all text-xs"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Verifying Stock & Placing...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>Confirm & Place Order (₹{grandTotal})</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
