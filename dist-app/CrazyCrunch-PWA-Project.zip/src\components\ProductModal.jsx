import React, { useState, useEffect, useRef } from 'react';
import { X, Check, AlertCircle, Image as ImageIcon, Upload, Loader2, Trash2 } from 'lucide-react';

const PRESET_IMAGES = [
  { label: 'Chakli', url: '/images/chakli.svg' },
  { label: 'Mini Stuffed', url: '/images/mini-stuffed.svg' },
  { label: 'Crispy Sev', url: '/images/sev.svg' },
  { label: 'Mamra Laddu', url: '/images/mamra-laddu.svg' },
  { label: 'Coconut Biscuits', url: '/images/coconut-biscuits.svg' },
  { label: 'Crispy Khari', url: '/images/khari.svg' },
  { label: 'Dry Fruit Laddu', url: '/images/dryfruit-laddu.svg' },
  { label: 'Crazy Crunch Logo', url: '/icons/icon-192.svg' }
];

export default function ProductModal({ isOpen, onClose, product, onSave, token }) {
  if (!isOpen) return null;

  const isEditing = Boolean(product && product.id);
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    category: 'Crispy Savouries',
    price: 50,
    weight: '200 g',
    stock: 25,
    description: '',
    image: '/images/chakli.svg',
    isPublished: true,
    isDemoPrice: true
  });

  const [error, setError] = useState('');

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadError('');
    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowed.includes(file.type)) {
      setUploadError('Invalid format. Please upload JPG, PNG, or WebP images only.');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Photo exceeds the maximum 5 MB file size limit.');
      return;
    }

    setUploading(true);
    try {
      const activeToken = token || localStorage.getItem('cc_admin_token') || '';
      const data = new FormData();
      data.append('photo', file);

      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${activeToken}`
        },
        body: data
      });

      const result = await res.json();
      if (!res.ok || !result.success) {
        throw new Error(result.error || 'Failed to upload photo.');
      }

      setFormData((prev) => ({ ...prev, image: result.url }));
    } catch (err) {
      setUploadError(err.message || 'Image upload failed. Please try again.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name || '',
        category: product.category || 'Crispy Savouries',
        price: product.price !== undefined ? product.price : 50,
        weight: product.weight || '200 g',
        stock: product.stock !== undefined ? product.stock : 25,
        description: product.description || '',
        image: product.image || '/images/chakli.svg',
        isPublished: product.isPublished !== undefined ? product.isPublished : true,
        isDemoPrice: product.isDemoPrice !== undefined ? product.isDemoPrice : false
      });
    } else {
      setFormData({
        name: '',
        category: 'Crispy Savouries',
        price: 50,
        weight: '200 g',
        stock: 25,
        description: '',
        image: '/images/chakli.svg',
        isPublished: true,
        isDemoPrice: false
      });
    }
  }, [product]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setError('Please enter a product name.');
      return;
    }
    if (formData.price === undefined || formData.price < 0) {
      setError('Please enter a valid price.');
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl relative my-8 border border-orange-100 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-lg font-bold text-slate-900">
              {isEditing ? 'Edit Snack Product' : 'Add New Snack Product'}
            </h3>
            <p className="text-xs text-slate-500">Update pricing, weight, stock, and photos</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-3 p-2.5 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs text-red-700">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Scrollable Form */}
        <form id="product-form" onSubmit={handleSubmit} className="flex-1 overflow-y-auto py-4 space-y-3.5 pr-1">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Snack / Product Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Special Chakli"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Category
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white"
              >
                <option value="Crispy Savouries">Crispy Savouries</option>
                <option value="Traditional Sweets">Traditional Sweets</option>
                <option value="Bakery & Biscuits">Bakery & Biscuits</option>
                <option value="Festive Special">Festive Special</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Price (₹) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                step="1"
                required
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Pack Weight
              </label>
              <input
                type="text"
                placeholder="e.g. 200 g or 250 g"
                value={formData.weight}
                onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Stock Quantity (Packs)
              </label>
              <input
                type="number"
                min="0"
                step="1"
                value={formData.stock}
                onChange={(e) => setFormData({ ...formData, stock: Number(e.target.value) })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Description
            </label>
            <textarea
              rows={2}
              placeholder="Fresh homemade snacks description..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white resize-none"
            ></textarea>
          </div>

          {/* Product Photo Upload & Image Selection */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Product Photo / Image <span className="text-red-500">*</span>
            </label>

            {uploadError && (
              <div className="p-2 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs text-red-700">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{uploadError}</span>
              </div>
            )}

            {/* Current Image Preview & Upload Controls */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col sm:flex-row items-center gap-3.5">
              <div className="w-20 h-20 bg-white rounded-xl border border-slate-200 p-1.5 flex items-center justify-center shrink-0 shadow-inner relative overflow-hidden group">
                <img
                  src={formData.image || '/images/chakli.svg'}
                  alt="Product preview"
                  className="w-full h-full object-contain rounded-lg"
                />
                {uploading && (
                  <div className="absolute inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center text-white">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                )}
              </div>

              <div className="flex-1 w-full space-y-2 text-center sm:text-left">
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/jpeg,image/png,image/webp"
                    onChange={handleFileUpload}
                    className="hidden"
                    disabled={uploading}
                  />

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    className="px-3.5 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-orange-600/20 transition-all active:scale-95 disabled:bg-slate-300"
                  >
                    {uploading ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Uploading Photo...</span>
                      </>
                    ) : (
                      <>
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload Photo (Gallery / Files)</span>
                      </>
                    )}
                  </button>

                  {formData.image && formData.image !== '/images/chakli.svg' && (
                    <button
                      type="button"
                      onClick={() => setFormData((prev) => ({ ...prev, image: '/images/chakli.svg' }))}
                      className="px-2.5 py-2 text-slate-500 hover:text-red-600 hover:bg-slate-100 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
                      title="Reset to default"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove</span>
                    </button>
                  )}
                </div>

                <p className="text-[11px] text-slate-500">
                  Select JPG, PNG, or WebP from your phone gallery or laptop (max 5 MB).
                </p>
              </div>
            </div>

            {/* Quick Presets */}
            <div>
              <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                Or choose from preset demo snacks:
              </span>
              <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                {PRESET_IMAGES.map((preset) => (
                  <button
                    type="button"
                    key={preset.url}
                    onClick={() => setFormData({ ...formData, image: preset.url })}
                    className={`p-1 rounded-xl border flex flex-col items-center gap-0.5 transition-all ${
                      formData.image === preset.url
                        ? 'border-orange-500 bg-orange-50 ring-2 ring-orange-500/20'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <img src={preset.url} alt={preset.label} className="w-7 h-7 object-contain rounded" />
                    <span className="text-[8px] font-medium text-slate-600 truncate w-full text-center">
                      {preset.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Toggles */}
          <div className="pt-2 border-t border-slate-100 space-y-2">
            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.isPublished}
                onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                className="w-4 h-4 text-orange-600 rounded accent-orange-600 cursor-pointer"
              />
              <span className="text-xs font-bold text-slate-800">
                Published (Visible in customer catalogue)
              </span>
            </label>

            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.isDemoPrice}
                onChange={(e) => setFormData({ ...formData, isDemoPrice: e.target.checked })}
                className="w-4 h-4 text-amber-600 rounded accent-amber-600 cursor-pointer"
              />
              <span className="text-xs font-semibold text-slate-600">
                Mark as "Demo Price" badge
              </span>
            </label>
          </div>
        </form>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800"
          >
            Cancel
          </button>
          <button
            type="submit"
            form="product-form"
            className="px-5 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold text-xs shadow-md shadow-orange-600/20"
          >
            {isEditing ? 'Save Changes' : 'Create Product'}
          </button>
        </div>
      </div>
    </div>
  );
}
