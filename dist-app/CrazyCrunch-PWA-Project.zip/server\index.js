import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { fileURLToPath } from 'url';
import { db } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.join(__dirname, '..');
const DIST_DIR = path.join(ROOT_DIR, 'dist');
const PUBLIC_DIR = path.join(ROOT_DIR, 'public');
const UPLOADS_DIR = path.join(PUBLIC_DIR, 'uploads');

// Ensure uploads folder exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Multer storage configuration for persistent product photos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const cleanName = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '');
    const filename = `snack-${Date.now()}-${cleanName || 'photo'}${ext}`;
    cb(null, filename);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB max
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/;
    const extname = allowed.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowed.test(file.mimetype);
    if (extname && mimetype) {
      return cb(null, true);
    }
    cb(new Error('Invalid file format. Please upload JPG, PNG, or WebP images only.'));
  }
});

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json());
// Serve uploads statically
app.use('/uploads', express.static(UPLOADS_DIR));

// Simple Bearer token authentication for admin endpoints
// Supports customizable environment variable or default secure key
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'crazy-crunch-admin-session-secure-2026';

function requireAdmin(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: 'Unauthorized: Owner login required.' });
  }
  const token = authHeader.split(' ')[1];
  if (token !== ADMIN_TOKEN) {
    return res.status(403).json({ success: false, error: 'Forbidden: Invalid admin session.' });
  }
  next();
}

// --------------------------------------------------------------------------
// Public API Routes
// --------------------------------------------------------------------------

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString(), app: 'Crazy Crunch' });
});

// Public store settings
app.get('/api/settings', (req, res) => {
  res.json({ success: true, settings: db.getSettings() });
});

// Public customer products
app.get('/api/products', (req, res) => {
  try {
    const products = db.getProducts(false);
    res.json({ success: true, products });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --------------------------------------------------------------------------
// Real-time Owner Notifications (Server-Sent Events)
// --------------------------------------------------------------------------
const activeOwnerClients = new Set();

function notifyOwnerClients(eventPayload) {
  const data = `data: ${JSON.stringify(eventPayload)}\n\n`;
  for (const client of activeOwnerClients) {
    try {
      client.write(data);
    } catch (err) {
      activeOwnerClients.delete(client);
    }
  }
}

// Place customer order with server verification
app.post('/api/orders', (req, res) => {
  try {
    const { items, customer, paymentMethod } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, error: 'Your cart is empty.' });
    }

    if (
      !customer ||
      !customer.name?.trim() ||
      !customer.phone?.trim() ||
      !customer.address?.trim() ||
      !customer.area?.trim() ||
      !customer.city?.trim() ||
      !customer.pincode?.trim()
    ) {
      return res.status(400).json({
        success: false,
        error: 'Please fill in all required delivery fields: Full Name, Mobile Number, Complete Address, Area / Locality, City, and PIN Code.'
      });
    }

    // Phone number format validation (Indian 10-digit)
    const cleanPhone = customer.phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 10) {
      return res.status(400).json({
        success: false,
        error: 'Please enter a valid 10-digit mobile number.'
      });
    }

    // PIN code validation (Indian 6-digit)
    const cleanPincode = customer.pincode.replace(/[^0-9]/g, '');
    if (cleanPincode.length !== 6) {
      return res.status(400).json({
        success: false,
        error: 'Please enter a valid 6-digit delivery PIN code.'
      });
    }

    // Create order atomically
    const order = db.createOrder({
      items,
      customer: {
        name: customer.name.trim(),
        phone: cleanPhone.slice(-10),
        address: customer.address.trim(),
        area: customer.area.trim(),
        city: customer.city.trim(),
        pincode: cleanPincode,
        notes: customer.notes ? customer.notes.trim() : ''
      },
      paymentMethod: paymentMethod === 'UPI' ? 'UPI' : 'COD'
    });

    // Notify connected owner dashboard instances immediately
    notifyOwnerClients({
      type: 'NEW_ORDER',
      order
    });

    res.status(201).json({
      success: true,
      message: 'Order placed successfully!',
      order
    });
  } catch (err) {
    console.error('Order placement error:', err.message);
    res.status(400).json({ success: false, error: err.message });
  }
});

// --------------------------------------------------------------------------
// Owner / Admin API Routes (Protected)
// --------------------------------------------------------------------------

// Owner Login
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, error: 'Username and password are required.' });
  }

  const isValid = db.verifyOwnerCredentials(username, password);
  if (!isValid) {
    return res.status(401).json({ success: false, error: 'Invalid owner ID or password.' });
  }

  res.json({
    success: true,
    message: 'Welcome back, Owner!',
    token: ADMIN_TOKEN
  });
});

// Upload Product Photo (Owner only)
app.post('/api/admin/upload', requireAdmin, (req, res) => {
  upload.single('photo')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ success: false, error: 'Image exceeds maximum 5 MB file size limit.' });
      }
      return res.status(400).json({ success: false, error: `Upload error: ${err.message}` });
    } else if (err) {
      return res.status(400).json({ success: false, error: err.message });
    }

    if (!req.file) {
      return res.status(400).json({ success: false, error: 'No image file was received. Please select a photo.' });
    }

    const fileUrl = `/uploads/${req.file.filename}`;
    res.status(201).json({
      success: true,
      message: 'Photo uploaded successfully!',
      url: fileUrl,
      filename: req.file.filename
    });
  });
});

// Get all products (including unpublished)
app.get('/api/admin/products', requireAdmin, (req, res) => {
  const products = db.getProducts(true);
  res.json({ success: true, products });
});

// Create product
app.post('/api/admin/products', requireAdmin, (req, res) => {
  try {
    const { name, category, price, weight, description, stock, image, isPublished, isDemoPrice } = req.body;
    if (!name || price === undefined) {
      return res.status(400).json({ success: false, error: 'Product name and price are required.' });
    }

    const product = db.createProduct({
      name,
      category,
      price,
      weight,
      description,
      stock,
      image,
      isPublished,
      isDemoPrice
    });

    res.status(201).json({ success: true, product });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Update product
app.put('/api/admin/products/:id', requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const updated = db.updateProduct(id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, error: 'Product not found.' });
    }
    res.json({ success: true, product: updated });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Delete product
app.delete('/api/admin/products/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  const deleted = db.deleteProduct(id);
  if (!deleted) {
    return res.status(404).json({ success: false, error: 'Product not found.' });
  }
  res.json({ success: true, message: 'Product deleted successfully.' });
});

// Real-time SSE endpoint for owner dashboard notifications
app.get('/api/admin/events', (req, res) => {
  const token = req.query.token || (req.headers.authorization && req.headers.authorization.split(' ')[1]);
  if (token !== ADMIN_TOKEN) {
    return res.status(403).json({ success: false, error: 'Forbidden: Invalid session token.' });
  }

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive'
  });

  // Keep-alive heartbeat every 20 seconds
  const heartbeat = setInterval(() => {
    try {
      res.write(': heartbeat\n\n');
    } catch (e) {
      clearInterval(heartbeat);
    }
  }, 20000);

  res.write(`data: ${JSON.stringify({ type: 'CONNECTED', message: 'Real-time order notification stream active' })}\n\n`);
  activeOwnerClients.add(res);

  req.on('close', () => {
    clearInterval(heartbeat);
    activeOwnerClients.delete(res);
  });
});

// Get all orders
app.get('/api/admin/orders', requireAdmin, (req, res) => {
  const orders = db.getOrders();
  res.json({ success: true, orders });
});

// Update order status
app.put('/api/admin/orders/:id/status', requireAdmin, (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const validStatuses = ['New', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled'];

  if (!status || !validStatuses.includes(status)) {
    return res.status(400).json({ success: false, error: 'Invalid order status.' });
  }

  const updatedOrder = db.updateOrderStatus(id, status);
  if (!updatedOrder) {
    return res.status(404).json({ success: false, error: 'Order not found.' });
  }

  res.json({ success: true, order: updatedOrder });
});

// Dashboard stats summary
app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const products = db.getProducts(true);
  const orders = db.getOrders();

  const totalRevenue = orders
    .filter((o) => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + (o.grandTotal || 0), 0);

  const activeOrders = orders.filter((o) => ['New', 'Confirmed', 'Preparing', 'Out for Delivery'].includes(o.status)).length;
  const lowStockProducts = products.filter((p) => p.stock <= 5);

  res.json({
    success: true,
    stats: {
      totalRevenue,
      totalOrders: orders.length,
      activeOrders,
      lowStockCount: lowStockProducts.length,
      lowStockProducts
    }
  });
});

// --------------------------------------------------------------------------
// 404 Handler for Unmatched API Endpoints
// --------------------------------------------------------------------------
app.all('/api/*', (req, res) => {
  res.status(404).json({ success: false, error: 'API endpoint not found.' });
});

// --------------------------------------------------------------------------
// Static Files & PWA assets
// --------------------------------------------------------------------------

// Serve static public assets (icons, manifest, svgs)
app.use(express.static(PUBLIC_DIR));

// Serve Vite build output if it exists
if (fs.existsSync(DIST_DIR)) {
  app.use(express.static(DIST_DIR));
  app.get('*', (req, res) => {
    res.sendFile(path.join(DIST_DIR, 'index.html'));
  });
} else {
  // If dist is not yet built, serve public or helpful fallback
  app.get('*', (req, res) => {
    if (fs.existsSync(path.join(PUBLIC_DIR, 'index.html'))) {
      res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
    } else {
      res.send(`
        <h1>Crazy Crunch API Server</h1>
        <p>The backend is active on port ${PORT}. Run <code>npm run dev</code> or <code>npm run build</code> for the frontend UI.</p>
      `);
    }
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🍟 Crazy Crunch server running at http://localhost:${PORT}`);
});
